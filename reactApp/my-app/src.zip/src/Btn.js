import React from 'react';

 
export default class Form extends React.Component {
  constructor(props) {
    super(props);
    this.state = {value: ''};
    this.handleSubmit = this.handleSubmit.bind(this);
  }
 
  handleSubmit(event) {
	this.setState({value: 'Button clicked'});
	alert(this.props.value_1+"_______props_________"+this.props.value_2);
    event.preventDefault();
  }
  

  render() {
     let letterStyle = {
        padding: 5,
        margin: 5,
        display: "inline-block"
      };
    return (
       
        <div>
        <div style={letterStyle}  onClick={this.handleSubmit}>&lt;</div>
        <div style={letterStyle}  onClick={this.handleSubmit}>&gt;</div>
		    </div>
      
    );
  }
}

