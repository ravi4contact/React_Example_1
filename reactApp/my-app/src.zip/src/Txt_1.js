import React from 'react';


 
export default class Form extends React.Component {
  constructor(props) {
    super(props);
    this.state = {value: ''};

    this.handleChange = this.handleChange.bind(this);
    
  }

  handleChange(event) {
    this.setState({value: event.target.value});
	this.props.callbackFromParent(event.target.value);
  }
  

  render() {
   

let roomNoData =["Oak"];

console.log(roomNoData);
let uniqueroomNoData = roomNoData.filter(function(elem, i, array) {
        return array.indexOf(elem) === i;
    }
);
console.log(uniqueroomNoData);




   const days =[

     {
        "day": "Mon ",
        "date": "01"
      },
      {
        "day": "Tue ",
        "date": "02"
      },
        {
        "day": "Wed ",
        "date": "03"
      },
      {
        "day": "Thur ",
        "date": "04"
      },
        {
        "day": "Fri ",
        "date": "05"
      },
      {
        "day": "Sat ",
        "date": "06"
      },
        {
        "day": "Sun ",
        "date": "07"
      }

   ];
   
   const daylist = days.map((elm) =>
      <div style={{float:'left',border:'1px solid black',padding:'10px'}} key={elm.day}>
        {elm.day}{elm.date }
      </div>
    );
   console.log(daylist);


      const uniqueRoomlist = uniqueroomNoData.map((number) =>
      <div>
        <div style={{float:'left',border:'1px solid black',padding:'20px'}} key={number.toString()}>
          {number}
        </div>
         <div style={{float:'right',border:'1px solid black',padding:'10px'}}>{daylist}</div>
         </div>
      );
    return (
		<div>
       
    <div style={{ display: "inline-block"}}>{uniqueRoomlist}</div>
   
        
		</div>
        
    );
  }
}