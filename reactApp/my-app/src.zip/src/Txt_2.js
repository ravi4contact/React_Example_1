import React from 'react';



 
export default class Form extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      entries: []
    };
    
  }

   /*componentDidMount() {

      $.ajax({
          url: 'http://www.mocky.io/v2/591596dc100000b9027595b1',
          dataType: 'json',
          cache: false,
          success: function(data) {
            this.setState({entries: data});
            console.log('success');
          }.bind(this),
          error: function(xhr, status, err) {
            console.error(this.props.url, status, err.toString());
            console.log('fail');
          }.bind(this)
        });
    
   }*/
  

  render() {
    const bookingData = [
  {
    "roomType": "oak",
    "roomNumber": "1",
    "checkIn": "01-01-2017",
    "checkOut": "05-01-2017"
  },
  {
    "roomType": "oak",
    "roomNumber": "2",
    "checkIn": "01-01-2017",
    "checkOut": "02-01-2017"
  },
  {
    "roomType": "oak",
    "roomNumber": "2",
    "checkIn": "04-01-2017",
    "checkOut": "07-01-2017"
  },
  {
    "roomType": "maple",
    "roomNumber": "3",
    "checkIn": "03-01-2017",
    "checkOut": "06-01-2017"
  },
  {
    "roomType": "maple",
    "roomNumber": "4",
    "checkIn": "01-01-2017",
    "checkOut": "02-01-2017"
  },
  {
    "roomType": "oak",
    "roomNumber": "2",
    "checkIn": "08-01-2017",
    "checkOut": "10-01-2017"
  },
  {
    "roomType": "oak",
    "roomNumber": "2",
    "checkIn": "11-01-2017",
    "checkOut": "12-01-2017"
  },
  {
    "roomType": "maple",
    "roomNumber": "3",
    "checkIn": "14-01-2017",
    "checkOut": "15-01-2017"
  },
  {
    "roomType": "maple",
    "roomNumber": "4",
    "checkIn": "10-01-2017",
    "checkOut": "12-01-2017"
  },
  {
    "roomType": "maple",
    "roomNumber": "5",
    "checkIn": "10-01-2017",
    "checkOut": "14-01-2017"
  }
];

console.log(bookingData[0].roomNumber);

let roomNoData = bookingData.map(function(elem) {
    return elem.roomNumber;
}); 
console.log(roomNoData);
let uniqueroomNoData = roomNoData.filter(function(elem, i, array) {
        return array.indexOf(elem) === i;
    }
);
console.log(uniqueroomNoData);




   const days =[

     {
        "day": "Mon ",
        "date": "01"
      },
      {
        "day": "Tue ",
        "date": "02"
      },
        {
        "day": "Wed ",
        "date": "03"
      },
      {
        "day": "Thur ",
        "date": "04"
      },
        {
        "day": "Fri ",
        "date": "05"
      },
      {
        "day": "Sat ",
        "date": "06"
      },
        {
        "day": "Sun ",
        "date": "07"
      }

   ];
   
   const daylist = days.map((elm) =>
      <div style={{float:'left',border:'1px solid black',padding:'10px',width:"50px"}} key={elm.day}>
      
      </div>
    );
   console.log(daylist);


      const uniqueRoomlist = uniqueroomNoData.map((number) =>
      <div>
        <div style={{float:'left',border:'1px solid black',padding:'10px'}} key={number.toString()}>
          {number}
        </div>
         <div style={{float:'right',border:'1px solid black',padding:'10px'}}>{daylist}</div>
         </div>
      );
    return (
		<div>
       
    <div style={{ display: "inline-block"}}>{uniqueRoomlist}</div>
   
        
		</div>
        
    );
  }
}